package com.example.appnacfequeagoravai;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class webmotors extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webmotors);


        WebView webviewWebmotors = findViewById(R.id.webviewWebmotors);
        webviewWebmotors.setWebViewClient(new WebViewClient());

        webviewWebmotors.getSettings().setJavaScriptEnabled(true);

        webviewWebmotors.loadUrl("https://www.webmotors.com.br/");
    }
}
