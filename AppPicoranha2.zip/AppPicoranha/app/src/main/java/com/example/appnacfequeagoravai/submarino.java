package com.example.appnacfequeagoravai;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class submarino extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submarino);

        WebView webviewSubmarino = findViewById(R.id.webviewSubmarino);
        webviewSubmarino.setWebViewClient(new WebViewClient());

        webviewSubmarino.getSettings().setJavaScriptEnabled(true);

        webviewSubmarino.loadUrl("https://www.submarino.com.br");
    }
}
