package com.example.appnacfequeagoravai;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class magalu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_magalu);

        WebView webviewMagalu = findViewById(R.id.webviewMagalu);
        webviewMagalu.setWebViewClient(new WebViewClient());

        webviewMagalu.getSettings().setJavaScriptEnabled(true);

        webviewMagalu.loadUrl("https://www.magazineluiza.com.br/");
    }
}
