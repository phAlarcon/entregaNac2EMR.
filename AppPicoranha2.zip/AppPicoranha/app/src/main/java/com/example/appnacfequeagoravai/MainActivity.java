package com.example.appnacfequeagoravai;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onWebmotors(View view){

        Intent intentWebmotors = new Intent(this,webmotors.class);
        startActivity(intentWebmotors);
    }

    public void onSubmarino(View view){

        Intent intentSubmarino = new Intent(this,submarino.class);
        startActivity(intentSubmarino);
    }

    public void onAmericanas(View view){

        Intent intentAmericanas = new Intent(this,americanas.class);
        startActivity(intentAmericanas);
    }

    public void onNetshoes(View view){

        Intent intentNetshoes = new Intent(this,netshoes.class);
        startActivity(intentNetshoes);
    }

    public void onMagalu(View view){

        Intent intentMagalu = new Intent(this,magalu.class);
        startActivity(intentMagalu);
    }

    public void onEbay(View view){

        Intent intentEbay = new Intent(this,ebay.class);
        startActivity(intentEbay);
    }

    public void onSobre(View view){

        Intent intentSobre = new Intent(this,sobre.class);
        startActivity(intentSobre);
    }

}
